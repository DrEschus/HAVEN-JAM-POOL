extends Node2D

var jezirkokod: PackedScene = load("res://sceny/jezirko.tscn")

func _ready() -> void:
	print("start")
	pass



func _input(event) -> void:
	if event.is_action_pressed("rezani"):
		$jezirko/Timer.start()
		print("odeslano")
		vytvorit_jezirko()

# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass




func _on_timer_timeout() -> void:
	print("hotovo")
	$jezirko/Timer.stop()
	
	
func vytvorit_jezirko():
	
	
	var jezirko = jezirkokod.instantiate()
	$jezirko.add_child(jezirko)
	jezirko.position = $eskymak.global_position
	print(str($eskymak.global_position))
