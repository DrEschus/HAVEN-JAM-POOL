class_name jezeroklon
extends StaticBody2D


func _ready():
	print("ziju")

	
