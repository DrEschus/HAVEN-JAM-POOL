
extends CharacterBody2D
signal zacatekrezani

@export var rychlost = 200

var posledni: Array = []

	
func _physics_process(delta) :
	var smer := Input.get_vector("left", "right", "up", "down")
	
	posledni.append(smer * rychlost * delta)
	if posledni.size() > 30:
		posledni.remove_at(0)
	var soucetpozic := Vector2.ZERO
	for pozice in posledni:
		soucetpozic = soucetpozic + pozice
	var prumerpozic = soucetpozic/ posledni.size() # prumeruje
	if (smer * rychlost * delta) == Vector2.ZERO:
		$AnimatedSprite2D.play("default")

	
	position += (prumerpozic)
	
	move_and_slide()

func _input(event) -> void:
	if event.is_action_pressed("left"):
		$AnimatedSprite2D.play("doleva")
	if event.is_action_pressed("right"):
		$AnimatedSprite2D.play("doprava")
	
