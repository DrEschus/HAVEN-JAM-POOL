extends Node2D

var fixed_point = Vector2(0, 0) # Pevná souřadnice

func _process(delta: float) -> void:
	var fixed_pos = $Sprite2D/Line2D.to_local(fixed_point)
	$Sprite2D/Line2D.set_point_position(1, fixed_pos)
	
