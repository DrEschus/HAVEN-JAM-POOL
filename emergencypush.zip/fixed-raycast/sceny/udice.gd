extends CharacterBody2D

var nahozeno: bool = false
var tween: Tween
var zaklad: Vector2 = Vector2(22, -22)

func _input(event):
	if event.is_action_pressed("nahozeni"):
		if nahozeno == false:
			var aktualnipozice = global_position

		# Plynulý pohyb objektu o 25 pixelů doprava
			tween = create_tween()
			tween.tween_property(
				self,
				"global_position",
				aktualnipozice + Input.get_vector("left", "right", "up", "down")*100,
				0.4
			).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
			nahozeno = true
			print("testtest")
			if $RayCast2D.is_colliding():
				$Timer.start()
				print("timer started")
			else:
				nahozeno = false
		else:
			if $Sprite2D2.visibility == true:
				pass    # SKORE ADD HERE
			nahozeno = false

func _ready():
	pass


func _process(delta: float) -> void:
	if nahozeno == false:
		position = $"../eskymak".position + zaklad
	pass
	
	


func _on_timer_timeout() -> void:
	$"../Medvidek/AnimatedSprite2D".visible = true
