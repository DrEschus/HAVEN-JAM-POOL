class_name jezeroklon
extends StaticBody2D


func _ready():
	print("ziju")
	$Timer.start()
	
	

func _on_timer_timeout() -> void:
	$AnimatedSprite2D.play("reverse")
	pass


func _on_animated_sprite_2d_animation_finished() -> void:
	$AnimatedSprite2D.stop()
	if $Timer.is_stopped() == true:
		self.queue_free()
