extends CharacterBody2D
var count: int = 0
var nahozeno: bool = false
var tween: Tween
var zaklad: Vector2 = Vector2(22, -22)
var chyceno := false

func _input(event):
	if event.is_action_pressed("nahozeni"):
		if nahozeno == false:
			var aktualnipozice = global_position

			tween = create_tween()
			tween.tween_property(
				self,
				"global_position",
				aktualnipozice + Input.get_vector("left", "right", "up", "down") * 100,
				0.4
			).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)

			nahozeno = true
			print("testtest")

		else:
			if chyceno == true:
				count +=1
				$Label.text = str(count)
				$Sprite2D2.visible = false

			chyceno = false
			nahozeno = false


func _physics_process(delta):
	if nahozeno:
		$RayCast2D.force_raycast_update()

		if $RayCast2D.is_colliding():
			if !$Timer.is_stopped() != true:
				$Timer.start()
				print("timer started")


func _process(delta: float) -> void:
	if nahozeno == false:
		position = $"../eskymak".position + zaklad
	else:
		if ($"../eskymak".position - self.position) > (Vector2(200,0)-Vector2(0,0)) == true:
			nahozeno = false

func _on_timer_timeout() -> void:
	$Timer.stop()
	if nahozeno ==true:
		$Sprite2D2.visible = true
		chyceno = true
		print("CHYCENOOO")
