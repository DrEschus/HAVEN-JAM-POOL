class_name jezeroklon
extends StaticBody2D


func _ready():
	print("ziju")
	#$Timer.start()
	#
	#
#
#func _on_timer_timeout() -> void:
	#$AnimatedSprite2D.play("reverse")
	#$Timer.stop()
	#pass
#
#
#func _on_animated_sprite_2d_animation_finished() -> void:
	#if $Timer.is_stopped() == true:
		#self.position = Vector2(1000,1000)
