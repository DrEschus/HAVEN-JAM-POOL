extends TextureRect
@onready var udice = $"../../../../udice"

@export var poradi:int = 0

func _ready() -> void:
	position = position + Vector2(5, 0)*poradi
	pass

func _process(delta: float) -> void:
	if udice.count >= poradi:
		self.visible = true
	pass
