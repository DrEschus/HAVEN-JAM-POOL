extends CharacterBody2D

var konec_hry: bool = false
@export var rychlost_meda = 100
var eskymak_misto
var cil_misto
@onready var player = $"../eskymak"

func _process(delta: float) -> void:
	if position.x > $"../eskymak".position.x:
		$AnimatedSprite2D.play("levybeh")
	else:
		$AnimatedSprite2D.play("pravybeh")
		

func _physics_process(delta: float) -> void:
	
	eskymak_misto = player.position
	cil_misto = (eskymak_misto - position).normalized()

	if position.distance_to(eskymak_misto) > 1:
		velocity = cil_misto * rychlost_meda
		move_and_slide()
	if  position.distance_to(eskymak_misto) < 20:
		konec_hry = true
	if konec_hry == true:
		get_tree().change_scene_to_file("res://game_over.tscn")
	
		
		
