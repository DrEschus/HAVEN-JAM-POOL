extends Control

@export var level_scene: PackedScene = load("res://sceny/main.tscn")

func _process(delta: float) -> void:
	if Input.is_action_just_pressed("start"):
		get_tree().change_scene_to_packed(level_scene)
