extends Node2D

 

func _process(delta: float) -> void:
	var fixed_point = $"../../udice".position
	var fixed_pos = $Sprite2D/Line2D.to_local(fixed_point)
	$Sprite2D/Line2D.set_point_position(1, fixed_pos)
	
