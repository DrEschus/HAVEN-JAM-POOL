extends Node2D

var cela_scela: PackedScene = load("res://sceny/main.tscn")
var jezirkokod: PackedScene = load("res://sceny/jezirko.tscn")
var story: PackedScene = load("res://story.tscn")
@onready var eskymak = $eskymak

# Stavová proměnná – určí, zda zrovna běží příběh
var is_story_active: bool = true
var story_layer = null
var story_node = null

func _ready() -> void:
	print("start příběhu")
	
	# Vytvoříme CanvasLayer, který zajistí, že příběh bude pevně na obrazovce bez offsetu kamery
	story_layer = CanvasLayer.new()
	story_node = story.instantiate()
	story_layer.add_child(story_node)
	add_child(story_layer)
	
	# Poznámka: $antilake.start() zatím nespouštíme, počkáme na konec příběhu.

func _process(delta: float) -> void:
	# Pokud ještě běží příběh, ignorujeme veškerou herní logiku v _process
	if is_story_active:
		return

	if $Timer.is_stopped():
		pass
	else:
		if eskymak.aktualni_smer != Vector2.ZERO:
			$Timer.stop()
			$eskymak/pravyduch.stop()
			$eskymak/levyduch.stop()
			print(eskymak.aktualni_smer)
			print("ZASTAVENO")

func _input(event) -> void:
	# Pokud běží příběh, čekáme na stisk klávesy nebo kliknutí myší pro jeho ukončení
	if is_story_active:
		if (event is InputEventKey and event.pressed) or (event is InputEventMouseButton and event.pressed):
			story_layer.queue_free()   # Odstraní celou vrstvu s příběhem z obrazovky
			is_story_active = false    # Přepne stav na "hra běží"
			print("Příběh skončil, spouštím hru!")
			$antilake.start()          # Teď teprve spustíme hru / timer antilake
		return # Dále v _input nepokračujeme, dokud je příběh aktivní

	# --- PŮVODNÍ HERNÍ INPUT LOGIKA ---
	if event.is_action_pressed("rezani"):
		$Timer.start()
		
		if eskymak.facingright == true:
			if $eskymak/pravy1check.is_colliding() or $eskymak/pravy2check.is_colliding():
				print("prvni pravy collide")
			else:
				$eskymak/pravyduch.play("prava_anima")
		else:
			if $eskymak/levy1check.is_colliding() or $eskymak/levy2check.is_colliding():
				print("prvni levy collide")
			else:
				$eskymak/levyduch.play("leva_anima")

func vytvorit_jezirko():
	var jezirko = jezirkokod.instantiate()
	$jezirko.add_child(jezirko)
	
	if eskymak.facingright == true:
		if $eskymak/pravy1check.is_colliding() or $eskymak/pravy2check.is_colliding():
			print("detectttt")
			$eskymak/pravyduch.stop()
			print("dtct2")
		else:
			jezirko.position = $eskymak.global_position + Vector2(66.9,0)
	else:
		if $eskymak/levy1check.is_colliding() or $eskymak/levy2check.is_colliding():
			$eskymak/levyduch.stop()
		else: 
			jezirko.position = $eskymak.global_position - Vector2(66.9,0)
	print(str($eskymak.global_position))

func _on_timer_timeout() -> void:
	vytvorit_jezirko()
	$Timer.stop()

func _on_pravyduch_animation_finished() -> void:
	pass

func _on_levyduch_animation_finished() -> void:
	pass
