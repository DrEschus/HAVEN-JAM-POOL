
extends CharacterBody2D


@export var rychlost = 200

var posledni: Array = []
var aktualni_smer:Vector2 = Vector2.ZERO
	
func _physics_process(delta) :
	var smer := Input.get_vector("left", "right", "up", "down")
	aktualni_smer = smer * rychlost * delta
	posledni.append(aktualni_smer)
	if posledni.size() > 30:
		posledni.remove_at(0)
	var soucetpozic := Vector2.ZERO
	for pozice in posledni:
		soucetpozic = soucetpozic + pozice
	var prumerpozic = soucetpozic/ posledni.size() # prumeruje
	if (smer * rychlost * delta) == Vector2.ZERO:
		$AnimatedSprite2D.play("default")
	
	position += (prumerpozic)
	
	move_and_slide()
	
var facingup: bool = true

	
var facingright: bool = true
func _input(event) -> void:
	if event.is_action_pressed("left"):
		facingright = false
		$AnimatedSprite2D.play("doleva")
	if event.is_action_pressed("right"):
		facingright = true
		$AnimatedSprite2D.play("doprava")
	if event.is_action_pressed("down"):
		facingup = false
		$AnimatedSprite2D.play("dolu")
	if event.is_action_pressed("up"):
		facingup = true
	
	


func _on_pravyduch_animation_finished() -> void:
	$pravyduch.stop()
	print("zastaveno")
