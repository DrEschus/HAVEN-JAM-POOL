extends Control

var level_scene: PackedScene = load("res://sceny/main.tscn")

func _process(delta: float) -> void:
	if Input.is_action_just_pressed("start"):
		pass
		#get_tree().change_scene_to_file(level_scene)
