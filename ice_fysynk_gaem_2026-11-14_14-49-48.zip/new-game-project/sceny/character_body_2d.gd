
extends CharacterBody2D

@export var rychlost = 200

var posledni: Array = []

	
func _physics_process(delta) :
	var smer := Input.get_vector("left", "right", "up", "down")
	
	posledni.append(smer * rychlost * delta)
	if posledni.size() > 30:
		posledni.remove_at(0)
	var soucetpozic := Vector2.ZERO
	for pozice in posledni:
		soucetpozic = soucetpozic + pozice
	var prumerpozic = soucetpozic/ posledni.size()
	
	position += (prumerpozic)
	
	move_and_slide()

	
