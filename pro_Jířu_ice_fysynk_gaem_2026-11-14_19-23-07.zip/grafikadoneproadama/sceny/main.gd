extends Node2D
	# if position.distance_to(eskymak_misto) > 3:
	#	move_and_slide(cil_misto * rychlost_meda)
	#	look_at(eskymak_misto)
#var dist = global_position.distance_to(target.global_position)
