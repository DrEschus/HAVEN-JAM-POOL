extends Node2D

var jezirkokod: PackedScene = load("res://sceny/jezirko.tscn")
@onready var eskymak = $eskymak
func _ready() -> void:
	print("start")
	
	pass

func _process(delta: float) -> void:
	if $Timer.is_stopped():
		pass
		
	else:
		if eskymak.aktualni_smer != Vector2.ZERO:
			$Timer.stop()
			$eskymak/pravyduch.stop()
			
			$eskymak/levyduch.stop()
			print(eskymak.aktualni_smer)
			print("ZASTAVENO")
		
	pass

func _input(event) -> void:
	if event.is_action_pressed("rezani"):
		$Timer.start()
		if eskymak.facingright == true:
			if $eskymak/pravy1check.is_colliding() or $eskymak/pravy2check.is_colliding():
				print("prvni pravy collide")
				
				pass
			else:
				$eskymak/pravyduch.play("prava_anima")
		else:
			if $eskymak/levy1check.is_colliding() or $eskymak/levy2check.is_colliding():
				print("prvni levy collide")
			else:
				$eskymak/levyduch.play("leva_anima")
				
			pass








	
	
func vytvorit_jezirko():
	
	var jezirko = jezirkokod.instantiate()
	$jezirko.add_child(jezirko)
	
	if eskymak.facingright == true:
		if $eskymak/pravy1check.is_colliding() or $eskymak/pravy2check.is_colliding():
			print("detectttt")
			$eskymak/pravyduch.stop()
			print("dtct2")
		else:
			jezirko.position = $eskymak.global_position + Vector2(66.9,0)
		
	else:
		if $eskymak/levy1check.is_colliding() or $eskymak/levy2check.is_colliding():
			$eskymak/levyduch.stop()
		else: 
			jezirko.position = $eskymak.global_position - Vector2(66.9,0)
	print(str($eskymak.global_position))



	


func _on_timer_timeout() -> void:
	vytvorit_jezirko()
	$Timer.stop()
	


func _on_pravyduch_animation_finished() -> void:
	pass


func _on_levyduch_animation_finished() -> void:
	pass
